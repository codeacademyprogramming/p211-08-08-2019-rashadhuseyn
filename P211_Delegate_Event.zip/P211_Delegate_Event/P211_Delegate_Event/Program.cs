﻿using System;
using System.Collections.Generic;

namespace P211_Delegate_Event
{
    class Program
    {
        //public delegate bool WordFilter(string word);
        static void Main()
        {
            #region delegate
            //var allWords = new List<string>
            //{
            //    "samir", "samir@code.az", "nurlaneliyev", "sebuhimv@code.az", "ramizmizmiz"
            //};

            //var emails = FilterWords(allWords, IsEmail);
            //var biggerWords = FilterWords(allWords, delegate (string w) { return w.Length >= 12; });
            //var evenWords = FilterWords(allWords, w => w.Length % 2 == 0);

            //foreach (var email in evenWords)
            //{
            //    Console.WriteLine(email);
            //}
            #endregion

            Account account = new Account(0);
            account.Deposit(1500);

            account.BalanceFinished += () =>
            {
                Console.WriteLine("Hesabda pul bitdi");
            };

            account.BalanceFinished += delegate ()
            {
                Console.WriteLine("Email gonderildi.");
            };

            account.BalanceFinished += SMSSender;

            account.Withdraw(300);
            account.Withdraw(701);
        }

        static void SMSSender()
        {
            Console.WriteLine("SMS gonderildi");
        }

        static List<string> FilterWords(List<string> words, Func<string, bool> wordFilter)
        {
            List<string> result = new List<string>();

            foreach (var word in words)
            {
                if(wordFilter(word))
                {
                    result.Add(word);
                }
            }

            return result;
        }
        public static bool IsEmail(string email) => email.IndexOf('@') != -1;
    }

    class Account
    {
        public event Action BalanceFinished;

        public Account(decimal balance)
        {
            Balance = balance;
        }

        private decimal _balance;
        public decimal Balance
        {
            get { return _balance; }
            set {
                if(value >= 0)
                {
                    _balance = value;
                    return;
                }

                throw new ArgumentException("Balance amount can not be negative amount");
            }
        }

        public decimal Deposit(decimal amount)
        {
            if (amount < 0) throw new ArgumentException("Amount can not be negative");

            Balance += amount;
            return Balance;
        }

        public void Withdraw(decimal amount)
        {
            if (amount < 0) throw new ArgumentException("Amount to withdraw can not be negative");

            if(Balance >= amount)
            {
                Balance -= amount;
                return;
            }

            BalanceFinished?.Invoke();

            //if (BalanceFinished != null)
            //{
            //    BalanceFinished();
            //}
        }
    }
}
